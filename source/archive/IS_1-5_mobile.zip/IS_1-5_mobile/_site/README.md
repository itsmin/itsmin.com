# mantle_mobile

base US Design Team prototyping skeleton (mobile)


SASS
http://sass-lang.com/
sass --watch app/sass:public/stylesheets

Server
https://www.npmjs.com/package/httpserver
httpserver
